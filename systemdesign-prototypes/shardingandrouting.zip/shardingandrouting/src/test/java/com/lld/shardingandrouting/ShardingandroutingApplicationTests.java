package com.lld.shardingandrouting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShardingandroutingApplicationTests {

	@Test
	void contextLoads() {
	}

}
