package com.lld.shardingandrouting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShardingandroutingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShardingandroutingApplication.class, args);
	}

}
